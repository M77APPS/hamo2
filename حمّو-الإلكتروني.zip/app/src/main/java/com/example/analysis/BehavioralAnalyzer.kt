package com.example.analysis

import android.content.Context
import android.os.Build
import android.util.Log
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class ScanResult {
    object Safe : ScanResult()
    data class Malicious(val message: String, val category: String) : ScanResult()
    data class Suspicious(val warning: String) : ScanResult()
    data class Phishing(val threatScore: Int, val details: String) : ScanResult()
    data class ZeroClickExploit(val matchPattern: String) : ScanResult()
}

class BehavioralAnalyzer(private val context: Context) {

    private val TAG = "BehavioralAnalyzer"

    // OkHttpClient with restricted 3-second limits and followRedirects = false
    // so we can detect hidden hopping redirects.
    private val client = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .writeTimeout(3, TimeUnit.SECONDS)
        .followRedirects(false)
        .build()

    /**
     * Conducts non-intrusive HEAD scans + network redirection checks + isolates in sandboxed WebView.
     */
    suspend fun analyze(url: String): ScanResult = withContext(Dispatchers.IO) {
        val formattedUrl = if (!url.startsWith("http://") && !url.startsWith("https://")) {
            "https://$url"
        } else {
            url
        }

        try {
            val request = Request.Builder()
                .url(formattedUrl)
                .head() // HEAD request strictly retrieves headers without loading page body payloads
                .header("User-Agent", "HemoSilentShield/2.0 (Mobile Sandbox Client)")
                .build()

            val response = client.newCall(request).execute()
            val code = response.code
            val contentType = response.header("Content-Type") ?: "text/html"
            val locationHeader = response.header("Location") ?: ""

            Log.d(TAG, "Behavioral Scan - Code: $code, Type: $contentType, Redirect Location: $locationHeader")

            // 1. Detect stealthy APK drive-by downloads
            if (contentType.contains("application/vnd.android.package-archive") || formattedUrl.endsWith(".apk")) {
                return@withContext ScanResult.Malicious(
                    message = "تم العثور على ملف APK مخفي مستهدف للتحميل المباشر خلسة.",
                    category = "Drive-by Trojan Payload Download"
                )
            }

            // 2. HTTP redirects analysis looking for suspicious phishing redirects
            if (code in 300..308 && locationHeader.isNotEmpty()) {
                val cleanLocation = locationHeader.lowercase()
                if (cleanLocation.contains("login") || cleanLocation.contains("signin") || cleanLocation.contains("verification")) {
                    return@withContext ScanResult.Phishing(
                        threatScore = 95,
                        details = "يوجد تحويل ديناميكي مشكوك به إلى صفحة تسجيل دخول لإستغلال الجلسات: $locationHeader"
                    )
                }
                return@withContext ScanResult.Suspicious(
                    warning = "الرابط يحتوي على تحويل مخفي فوري إلى وجهة خارجية: $locationHeader"
                )
            }

            // 3. Command injection or script execution signatures inside URL
            val zeroClickPatterns = listOf(".php?cmd=", ".py", ".sh", "/etc/", "system32", "cmd.exe", "powershell")
            for (pattern in zeroClickPatterns) {
                if (formattedUrl.contains(pattern, ignoreCase = true)) {
                    return@withContext ScanResult.ZeroClickExploit(
                        matchPattern = "تم كشف أمر تنفيذي $pattern في الرابط يهدف لاستغلال ثغرات Zero-day."
                    )
                }
            }

            // 4. Secure Sandbox WebView check simulation
            withContext(Dispatchers.Main) {
                runWebViewIsolationSanity(formattedUrl)
            }

            return@withContext ScanResult.Safe

        } catch (e: IOException) {
            Log.e(TAG, "Behavioral network analyzer unreachable", e)
            return@withContext ScanResult.Suspicious("الرابط غير مستقر أو خادم الويب الخاص به لم يستجب لفحص الـ HEAD.")
        } catch (e: Exception) {
            Log.e(TAG, "General scan fault", e)
            return@withContext ScanResult.Safe
        }
    }

    /**
     * Initializes structural isolated safe settings inside standard WebViews
     * with javascript and file system accesses completely disabled.
     */
    private fun runWebViewIsolationSanity(url: String) {
        try {
            val sandboxWebView = WebView(context).apply {
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                        return true // Keep trapped inside sandbox
                    }
                }
                settings.apply {
                    javaScriptEnabled = false // Block cross-site scripting
                    domStorageEnabled = false
                    allowFileAccess = false
                    allowContentAccess = false
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                        mediaPlaybackRequiresUserGesture = true
                    }
                }
            }
            // Trigger pre-emptive load inside detached virtual container
            sandboxWebView.loadUrl(url)
            Log.d(TAG, "Isolating web renderer sandbox successfully initialized for $url")
        } catch (e: Exception) {
            Log.e(TAG, "WebView container initialization bypassed", e)
        }
    }
}
