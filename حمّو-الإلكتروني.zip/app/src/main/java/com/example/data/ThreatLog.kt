package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "threat_logs")
data class ThreatLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val securityScore: Int, // 0 to 100
    val riskType: String, // SAFE, SUSPICIOUS, MALICIOUS, ZERO_DAY, REDIRECT_MALICIOUS
    val threatCategory: String, // "Phishing", "XSS Exploit", "Injection", "Malware Bundle", "Safe", etc.
    val analysisLog: String,
    val timestamp: Long = System.currentTimeMillis()
)
