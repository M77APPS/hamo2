package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ThreatLogDao {
    @Query("SELECT * FROM threat_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<ThreatLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ThreatLog)

    @Query("DELETE FROM threat_logs")
    suspend fun clearLogs()

    @Query("SELECT COUNT(*) FROM threat_logs")
    suspend fun getLogsCount(): Int

    @Query("SELECT COUNT(*) FROM threat_logs WHERE riskType != 'SAFE'")
    suspend fun getThreatsCount(): Int
}
