package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vault_items")
data class VaultItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val encryptedContent: String,
    val mimeType: String, // "text/plain", "credentials", "photo_description", etc.
    val isDecrypted: Boolean = false, // UI helper, not cached in db
    val timestamp: Long = System.currentTimeMillis()
)
