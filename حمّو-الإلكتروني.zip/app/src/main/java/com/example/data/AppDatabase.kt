package com.example.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [ThreatLog::class, VaultItem::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun threatLogDao(): ThreatLogDao
    abstract fun vaultItemDao(): VaultItemDao
}
