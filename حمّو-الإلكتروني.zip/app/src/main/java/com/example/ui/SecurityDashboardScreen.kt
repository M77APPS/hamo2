package com.example.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.VaultItem
import com.example.data.LinkScanResult
import com.example.service.HemoVpnService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecurityDashboardScreen(
    viewModel: SecurityViewModel,
    interceptedUrl: String?,
    onClearInterceptedUrl: () -> Unit,
    onToggleVpnRequested: (Boolean) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    var currentTab by remember { mutableStateOf("dashboard") }

    // State bindings
    val logs by viewModel.logs.collectAsState()
    val safetyScore by viewModel.safetyScore.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val currentScanResult by viewModel.currentScanResult.collectAsState()

    val vaultItems by viewModel.vaultItems.collectAsState()
    val sensitiveApps by viewModel.sensitiveAppList.collectAsState()
    val isScanningPermissions by viewModel.isScanningPermissions.collectAsState()

    val isVpnActive by viewModel.isVpnActive.collectAsState()
    val blockedUrlsCount by viewModel.blockedUrlsCount.collectAsState()

    // Interactive UI variables
    var manualUrlText by remember { mutableStateOf("") }
    var showVpnConsentDialog by remember { mutableStateOf(false) }

    // Cryptographic Vault inputs and validation
    var secretTitle by remember { mutableStateOf("") }
    var secretContent by remember { mutableStateOf("") }
    var vaultPinCode by remember { mutableStateOf("1234") }
    var activeDecryptedContent by remember { mutableStateOf<String?>(null) }
    var showUnlockDialogItem by remember { mutableStateOf<VaultItem?>(null) }
    var isBiometricLockEnabled by remember { mutableStateOf(false) }

    // TOTP Generator engine states
    var totpCode by remember { mutableStateOf("489 120") }
    var totpSecondsLeft by remember { mutableIntStateOf(30) }
    var totpProgress by remember { mutableStateOf(1.0f) }

    // Secure Isolated Web Sandbox url target
    var activeSandboxUrl by remember { mutableStateOf<String?>(null) }

    // Collaborative Intrusion Threat action warning dialog
    var showThreatActionDialog by remember { mutableStateOf(false) }
    var activeThreatResult by remember { mutableStateOf<LinkScanResult?>(null) }
    var expandMoreActions by remember { mutableStateOf(false) }

    // Intercepted Block Warning overlay state
    var activeBlockedUrlWarning by remember { mutableStateOf<String?>(null) }

    // Design Colors - Cyber Night theme (Neon greens/reds and glass transparency)
    val neonGreen = Color(0xFF00FF41)
    val neonRed = Color(0xFFFE2C55)
    val neonCyan = Color(0xFF00E5FF)
    val cyberDarkBg = Color(0xFF07090E)
    val glassCardBg = Color(0xFF111622)
    val glassBorder = Color(0xFF1E293B)

    // Respond immediately to deep URL intercept events
    LaunchedEffect(interceptedUrl) {
        if (!interceptedUrl.isNullOrBlank()) {
            manualUrlText = interceptedUrl
            currentTab = "scan"
            viewModel.scanManualUrl(interceptedUrl, useGemini = false)
            onClearInterceptedUrl()
        }
    }

    // Monitor TOTP ticking loop automatically
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            if (totpSecondsLeft > 1) {
                totpSecondsLeft -= 1
                totpProgress = totpSecondsLeft.toFloat() / 30f
            } else {
                totpSecondsLeft = 30
                totpProgress = 1.0f
                totpCode = "${(100..999).random()} ${(100..999).random()}"
            }
        }
    }

    // Monitor local scans for blocks (drop packet proxy simulation & show interactive dialog)
    LaunchedEffect(currentScanResult) {
        currentScanResult?.let { result ->
            if (result.riskType == "MALICIOUS" || result.riskType == "ZERO_DAY" || result.riskType == "REDIRECT_MALICIOUS") {
                activeThreatResult = result
                showThreatActionDialog = true
                expandMoreActions = false
            }
        }
    }

    // Main scaffold
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0C101B),
                tonalElevation = 8.dp,
                modifier = Modifier.border(1.dp, glassBorder, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            ) {
                NavigationBarItem(
                    selected = (currentTab == "dashboard"),
                    onClick = { currentTab = "dashboard" },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Dashboard", tint = if (currentTab == "dashboard") neonGreen else Color.Gray) },
                    label = { Text("اللوحة الحية", color = if (currentTab == "dashboard") neonGreen else Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                )
                NavigationBarItem(
                    selected = (currentTab == "scan"),
                    onClick = { currentTab = "scan" },
                    icon = { Icon(Icons.Default.Search, contentDescription = "Intelligence scan", tint = if (currentTab == "scan") neonGreen else Color.Gray) },
                    label = { Text("فحص الروابط", color = if (currentTab == "scan") neonGreen else Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                )
                NavigationBarItem(
                    selected = (currentTab == "vault"),
                    onClick = { currentTab = "vault" },
                    icon = { Icon(Icons.Default.Lock, contentDescription = "Cryptographic vault", tint = if (currentTab == "vault") neonGreen else Color.Gray) },
                    label = { Text("الخزنة والتحصين", color = if (currentTab == "vault") neonGreen else Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                )
                NavigationBarItem(
                    selected = (currentTab == "permissions"),
                    onClick = { currentTab = "permissions" },
                    icon = { Icon(Icons.Default.Build, contentDescription = "Permission radar", tint = if (currentTab == "permissions") neonGreen else Color.Gray) },
                    label = { Text("منظم الصلاحيات", color = if (currentTab == "permissions") neonGreen else Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                )
                NavigationBarItem(
                    selected = (currentTab == "about"),
                    onClick = { currentTab = "about" },
                    icon = { Icon(Icons.Default.Info, contentDescription = "Developer info", tint = if (currentTab == "about") neonGreen else Color.Gray) },
                    label = { Text("حول الدرع", color = if (currentTab == "about") neonGreen else Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(cyberDarkBg)
                .padding(innerPadding)
        ) {
            // Ambient cyber glow bubble
            Box(
                modifier = Modifier
                    .size(380.dp)
                    .align(Alignment.TopCenter)
                    .blur(160.dp)
                    .background(neonGreen.copy(alpha = 0.05f), CircleShape)
            )

            // Dynamic VPN Consent Dialog
            if (showVpnConsentDialog) {
                AlertDialog(
                    onDismissRequest = { showVpnConsentDialog = false },
                    confirmButton = {
                        Button(
                            onClick = {
                                showVpnConsentDialog = false
                                onToggleVpnRequested(true)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = neonGreen)
                        ) {
                            Text("أوافق وأفعل الآن", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showVpnConsentDialog = false }) {
                            Text("إلغاء الأمر", color = Color.Gray)
                        }
                    },
                    icon = { Icon(Icons.Default.Check, contentDescription = "VPN Consent", tint = neonGreen, modifier = Modifier.size(36.dp)) },
                    title = { Text("طلب تصريح تشغيل الدرع الصامت VPN", color = Color.White, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) },
                    text = {
                        Text(
                            text = "تطبيق واجهة حمّو الإلكتروني الدفاعية يقوم بإنشاء نفق محلي (Local VPN Tunnel Proxy) لتصفية حركة المرور وفحص طلبات DNS محلياً على جهازك لمطابقتها مع قوائم الثغرات السوداء وعزل الروابط الملعمة فوراً لحمايتك. نحن لا نقوم بتسريب أو مشاركة أي بيانات خارج جهازك مطلقاً.",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Right
                        )
                    },
                    containerColor = Color(0xFF0F1524),
                    modifier = Modifier.border(1.dp, neonGreen.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                )
            }

            // Interactive Master Vault decryption dialog
            showUnlockDialogItem?.let { item ->
                var pinAttempt by remember { mutableStateOf("") }
                AlertDialog(
                    onDismissRequest = { showUnlockDialogItem = null },
                    confirmButton = {
                        Button(
                            onClick = {
                                activeDecryptedContent = viewModel.decryptVaultItem(item, pinAttempt)
                                showUnlockDialogItem = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = neonGreen)
                        ) {
                            Text("فك التشفير AES", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    },
                    icon = { Icon(Icons.Default.Lock, contentDescription = "Unlock", tint = neonGreen) },
                    title = { Text("أدخل رمز PIN لفك التشفير", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("أدخل رمز الحماية المكون من 4 أرقام لفك التشفير الآمن:", color = Color.LightGray, fontSize = 12.sp)
                            OutlinedTextField(
                                value = pinAttempt,
                                onValueChange = { pinAttempt = it },
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = neonGreen,
                                    unfocusedBorderColor = Color.Gray,
                                    focusedTextColor = Color.White
                                )
                            )
                        }
                    },
                    containerColor = Color(0xFF0F1524),
                    modifier = Modifier.border(1.dp, neonGreen.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                )
            }

            // Main Views rendering of designated Tabs
            when (currentTab) {
                "dashboard" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("درع الدفاع السحابي والذاتي", fontSize = 11.sp, color = neonGreen, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Text("واجهة حمّو الإلكتروني الدفاعية", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.White)
                            }
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .background(if (isVpnActive) neonGreen.copy(alpha = 0.15f) else Color.Red.copy(alpha = 0.15f), CircleShape)
                                    .border(1.dp, if (isVpnActive) neonGreen else Color.Red, CircleShape)
                            )
                        }

                        // Circular Pulse Dial showing safety score
                        Box(
                            modifier = Modifier
                                .size(170.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.3f))
                                .border(2.dp, neonGreen.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$safetyScore%", fontSize = 44.sp, fontWeight = FontWeight.Black, color = Color.White)
                                Text("مستوى سلامة الاتصالات", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Toggle DNS VPN Active Card (Compliant VpnService interface)
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = glassCardBg),
                            border = BorderStroke(1.dp, if (isVpnActive) neonGreen.copy(alpha = 0.3f) else glassBorder)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .background(if (isVpnActive) neonGreen.copy(alpha = 0.1f) else Color.Gray.copy(alpha = 0.1f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "VPN Shield Status",
                                        tint = if (isVpnActive) neonGreen else Color.Gray,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isVpnActive) "الدرع الصامت نشط" else "الدرع الصامت غير مفعل",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color.White
                                    )
                                    Text(
                                        text = if (isVpnActive) "حمّو الإلكتروني يحميك ويعزل الروابط الضارة بالخلفية" else "موافق دائم مطلوبة - اضغط للتفعيل والحماية",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }
                                Switch(
                                    checked = isVpnActive,
                                    onCheckedChange = { active ->
                                        if (active) {
                                            showVpnConsentDialog = true
                                        } else {
                                            onToggleVpnRequested(false)
                                        }
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = neonGreen,
                                        checkedTrackColor = neonGreen.copy(alpha = 0.3f)
                                    )
                                )
                            }
                        }

                        // Community support card (No longer forcing subscription! 100% compliant)
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, neonCyan.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                                .clickable {
                                    try {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@hamoelectronic?si=JNc6FhqqChsNhQcF"))
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "فشل فتح الرابط الخارجي لقناة المجتمع", Toast.LENGTH_SHORT).show()
                                    }
                                },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1322))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .background(neonCyan.copy(alpha = 0.1f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "انضم لمجتمعنا",
                                        tint = neonCyan,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "انضم لمجتمع حمّو الإلكتروني 🚀",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "لتبقى على اطلاع بأحدث الثغرات وكيفية هندستها والحماية منها، انضم لقناتنا الرسمية الآن بسلاسة.",
                                        fontSize = 11.sp,
                                        color = Color.LightGray,
                                        lineHeight = 15.sp
                                    )
                                }
                                Icon(Icons.Default.PlayArrow, contentDescription = "اذهب", tint = neonCyan)
                            }
                        }

                        // Statistics card
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Card(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = glassCardBg),
                                border = BorderStroke(1.dp, glassBorder)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("محاولات الفحص", fontSize = 11.sp, color = Color.Gray)
                                    Text("${logs.size}", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                            Card(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = glassCardBg),
                                border = BorderStroke(1.dp, glassBorder)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("روابط محجوبة بالـ DNS", fontSize = 11.sp, color = Color.Gray)
                                    Text("$blockedUrlsCount", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = neonRed)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }

                "scan" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text("مستكشف الرغبات السيبرانية", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("أدخل الرابط المستهدف وسنقوم بمطابقته بـ Google Safe Browsing وتحليله وتفعيل تصفية VirusTotal الآمنة:", fontSize = 11.sp, color = Color.Gray)

                        OutlinedTextField(
                            value = manualUrlText,
                            onValueChange = { manualUrlText = it },
                            label = { Text("https://phishing-threat-link.net") },
                            modifier = Modifier.fillMaxWidth().testTag("scan_url_text"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = neonGreen,
                                unfocusedBorderColor = glassBorder
                            )
                        )

                        Button(
                            onClick = { viewModel.scanManualUrl(manualUrlText, useGemini = false) },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = neonGreen)
                        ) {
                            if (isScanning) {
                                CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(18.dp))
                            } else {
                                Text("تشغيل محرك الفحص المتكامل 🛡️", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Scanning loading indicator
                        if (isScanning) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = glassCardBg),
                                border = BorderStroke(1.dp, neonGreen.copy(alpha = 0.2f))
                            ) {
                                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    LinearProgressIndicator(color = neonGreen, modifier = Modifier.fillMaxWidth())
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("جار فحص الرابط عبر محرك Safe Browsing و VirusTotal في البيئة المعزولة لقناة حمّو...", color = neonGreen, fontSize = 11.sp)
                                }
                            }
                        }

                        // Scan Result Box
                        currentScanResult?.let { result ->
                            val isMalicious = result.riskType != "SAFE"
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, if (isMalicious) neonRed else neonGreen, RoundedCornerShape(16.dp)),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = glassCardBg)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(result.threatCategory, fontWeight = FontWeight.Bold, color = if (isMalicious) neonRed else neonGreen)
                                        Box(
                                            modifier = Modifier
                                                .background(if (isMalicious) neonRed.copy(alpha = 0.1f) else neonGreen.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(result.riskType, color = if (isMalicious) neonRed else neonGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    Divider(color = glassBorder)

                                    // Display detailed Google Safe Browsing and VirusTotal output
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text("Google Safe Browsing", fontSize = 10.sp, color = Color.Gray)
                                            Text(result.googleSafeBrowsingStatus, fontSize = 11.sp, color = if (result.googleSafeBrowsingStatus.contains("FLAGGED")) neonRed else Color.White, fontWeight = FontWeight.Bold)
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text("VirusTotal Engines", fontSize = 10.sp, color = Color.Gray)
                                            Text(result.virusTotalDetections, fontSize = 11.sp, color = if (isMalicious) neonRed else neonGreen, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    Divider(color = glassBorder)

                                    Text("التحليل السيبراني للحماية:", fontSize = 11.sp, color = Color.Gray)
                                    Text(result.summary, fontSize = 12.sp, color = Color.White, lineHeight = 16.sp, textAlign = TextAlign.Right)

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { viewModel.clearCurrentScanResult() },
                                            modifier = Modifier.weight(1f),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                                        ) {
                                            Text("إغلاق التقرير", fontSize = 11.sp, color = Color.White)
                                        }
                                    }
                                }
                            }
                        }

                        // Threats List Table
                        Text("سجلات التهديدات السابقة (${logs.size})", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        LazyColumn(
                            modifier = Modifier.height(180.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(logs) { log ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(glassCardBg, RoundedCornerShape(10.dp))
                                        .border(1.dp, glassBorder, RoundedCornerShape(10.dp))
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(log.url, fontSize = 11.sp, color = Color.LightGray, maxLines = 1)
                                        Text(log.threatCategory, fontSize = 9.sp, color = neonRed)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .background(neonRed.copy(alpha = 0.1f), CircleShape)
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text("معزول", color = neonRed, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                "vault" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text("الخزنة والتحصين المتقدم", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("قم بتشفير وحماية كلمات المرور، النصوص، والهويات الحساسة عبر معيار التشفير العسكري AES-256-GCM المخزن بمفتاح Android Keystore.", fontSize = 11.sp, color = Color.Gray)

                        // If decrypted content is active, display it highlighted in green warning
                        activeDecryptedContent?.let { content ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, neonGreen, RoundedCornerShape(12.dp)),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF091410))
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("محتوى فك التشفير الآمن", color = neonGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        IconButton(onClick = { activeDecryptedContent = null }) {
                                            Icon(Icons.Default.Close, contentDescription = "Close", tint = neonGreen)
                                        }
                                    }
                                    Text(content, color = Color.White, fontSize = 13.sp, textAlign = TextAlign.Right)
                                }
                            }
                        }

                        // Biometric & OTP Lock selectors
                        Text("ميزات التحصين وإدارة الهوية الأمنية", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F131E)),
                            border = BorderStroke(1.dp, glassBorder)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("ربط القفل الحيوي بمخزن Android Keystore 🧬", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("حماية الخزنة السيبرانية والتحويلات الخارجية ببصمة الهاتف", color = Color.Gray, fontSize = 11.sp)
                                    }
                                    Switch(
                                        checked = isBiometricLockEnabled,
                                        onCheckedChange = { isEnabled ->
                                            isBiometricLockEnabled = isEnabled
                                            if (isEnabled) {
                                                Toast.makeText(context, "تم ربط القفل الحيوي بمخزن Android Keystore لحماية التطبيق", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        colors = SwitchDefaults.colors(checkedThumbColor = neonGreen, checkedTrackColor = neonGreen.copy(alpha = 0.3f))
                                    )
                                }
                            }
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F131E)),
                            border = BorderStroke(1.dp, glassBorder)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier.size(10.dp).background(neonCyan, CircleShape)
                                        )
                                        Text("مُولد الرموز ثنائية الأمان (TOTP) ⏳", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                    Text("مؤقت: ${totpSecondsLeft}s", color = neonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                LinearProgressIndicator(
                                    progress = totpProgress,
                                    color = neonCyan,
                                    trackColor = Color.DarkGray,
                                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp))
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = totpCode,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Black,
                                    color = neonGreen,
                                    textAlign = TextAlign.Center,
                                    letterSpacing = 2.sp
                                )
                                Text("رمز الأمان الموقت للمصادقة الدفاعية والتأكيد التلقائي", color = Color.Gray, fontSize = 10.sp)
                            }
                        }

                        // Encryption Inputs
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = glassCardBg)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("حفظ وتشفير محتوى جديد بالخزنة", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)

                                OutlinedTextField(
                                    value = secretTitle,
                                    onValueChange = { secretTitle = it },
                                    label = { Text("عنوان المحتوى (مثال: حساب المحفظة البنكية)") },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = neonGreen, unfocusedBorderColor = glassBorder)
                                )

                                OutlinedTextField(
                                    value = secretContent,
                                    onValueChange = { secretContent = it },
                                    label = { Text("المحتوى السري لتشغيله وعزله") },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = neonGreen, unfocusedBorderColor = glassBorder)
                                )

                                OutlinedTextField(
                                    value = vaultPinCode,
                                    onValueChange = { vaultPinCode = it },
                                    label = { Text("رمز PIN المقترح لفك القفل ثنائياً") },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = neonGreen, unfocusedBorderColor = glassBorder)
                                )

                                Button(
                                    onClick = {
                                        viewModel.encryptAndSaveVaultItem(secretTitle, secretContent, vaultPinCode)
                                        secretTitle = ""
                                        secretContent = ""
                                        Toast.makeText(context, "تم التشفير والتخزين بالخزنة السيبرانية", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = neonGreen),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("تشفير وحفظ بالخزنة المشفرة AES 🔒", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }

                        // Encrypted database list
                        Text("الملفات والبيانات المحمية بالخزنة (${vaultItems.size})", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        
                        if (vaultItems.isEmpty()) {
                            Text("الخزنة السيبرانية فارغة حالياً.", color = Color.Gray, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                vaultItems.forEach { item ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(glassCardBg, RoundedCornerShape(10.dp))
                                            .border(1.dp, glassBorder, RoundedCornerShape(10.dp))
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(item.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                            Text("AES-256: ${item.encryptedContent.take(15)}...", fontSize = 10.sp, color = neonGreen)
                                        }
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Button(
                                                onClick = { showUnlockDialogItem = item },
                                                contentPadding = PaddingValues(horizontal = 8.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = neonGreen.copy(alpha = 0.2f)),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text("فك التشفير 🔒", color = neonGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                            IconButton(onClick = { viewModel.deleteVaultItem(item) }) {
                                                Icon(Icons.Default.Delete, contentDescription = "مسح", tint = Color.Gray)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                "about" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Brand Shield Icon
                        Box(
                            modifier = Modifier
                                .size(84.dp)
                                .background(neonGreen.copy(alpha = 0.1f), CircleShape)
                                .border(2.dp, neonGreen, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Info, contentDescription = "Developer Logo", tint = neonGreen, modifier = Modifier.size(42.dp))
                        }

                        Text("من نحن وتوثيق الهوية", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("بوابة المهندسين لدرع الفحص والتأمين الفوري المستقل", fontSize = 11.sp, color = neonGreen, fontWeight = FontWeight.Bold)

                        // Creator card info
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = glassCardBg),
                            border = BorderStroke(1.dp, glassBorder)
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("مهندس المشروع والمبتكر:", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("محمد حسام (حمّو الإلكتروني)", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
                                
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF0F1412), RoundedCornerShape(12.dp))
                                        .border(1.dp, neonGreen.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                        .padding(14.dp)
                                ) {
                                    Text(
                                        text = "“المحترفون يبنون أدواتهم، والهواة يستخدمون أدوات الآخرين.”",
                                        color = neonGreen,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }

                        // Defensive Disclaimer Card
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF140D0E)),
                            border = BorderStroke(1.dp, neonRed.copy(alpha = 0.4f))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Warning, contentDescription = "Policy Warning", tint = neonRed, modifier = Modifier.size(16.dp))
                                    Text("إخلاء مسؤولية رسمي وقانوني:", color = neonRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Text(
                                    text = "الاستخدام للأغراض الدفاعية والأخلاقية الشخصية فقط. التطبيق لا يتحكم بأجهزة المستخدمين أو بياناتهم دون إذنهم الصريح، ويلتزم تمامًا بقرارات ومتطلبات متجر جوجل بلاي.",
                                    color = Color.LightGray,
                                    fontSize = 11.sp,
                                    lineHeight = 16.sp,
                                    textAlign = TextAlign.Right
                                )
                            }
                        }

                        Text("إصدار درع حمو الصامت v4.2.0 - مستقر", color = Color.Gray, fontSize = 9.sp)
                    }
                }

                "permissions" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text("منظم ومستشار أذونات النظام", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("أداة تحليل الأذونات تبحث وتكشف كافة التطبيقات الحساسة التي تملك وصولاً للكاميرا والميكروفون والموقع الجغرافي، مع إمكانية تحويلك للنظام فوراً لإلغائها.", fontSize = 11.sp, color = Color.Gray)

                        Button(
                            onClick = { viewModel.scanDevicePermissions(context) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = neonGreen),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            if (isScanningPermissions) {
                                CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(18.dp))
                            } else {
                                Text("بدء مسح وتحليل الأذونات الحساسة 📲", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        // App permissions lists
                        sensitiveApps.forEach { appInfo ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F131E)),
                                border = BorderStroke(1.dp, glassBorder)
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(appInfo.appName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                                            Text(appInfo.packageName, fontSize = 10.sp, color = Color.Gray)
                                        }
                                        Button(
                                            onClick = {
                                                try {
                                                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                                        data = Uri.fromParts("package", appInfo.packageName, null)
                                                    }
                                                    context.startActivity(intent)
                                                } catch (e: Exception) {
                                                    Toast.makeText(context, "فشل فتح إعدادات النظام للتطبيق", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = neonRed.copy(alpha = 0.15f)),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("سحب الصلاحية ⛔", color = neonRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    // Permission Badges
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        if (appInfo.hasCamera) {
                                            Box(modifier = Modifier.background(neonRed.copy(alpha = 0.15f), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                                                Text("الكاميرا CAMERA", color = neonRed, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        if (appInfo.hasMic) {
                                            Box(modifier = Modifier.background(neonRed.copy(alpha = 0.15f), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                                                Text("الميكروفون MIC", color = neonRed, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        if (appInfo.hasLocation) {
                                            Box(modifier = Modifier.background(neonCyan.copy(alpha = 0.15f), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                                                Text("الموقع GPS", color = neonCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Intelligent Thread Action popup dialog when threat is detected (blocking, sandboxing, disconnect options)
            if (showThreatActionDialog && activeThreatResult != null) {
                AlertDialog(
                    onDismissRequest = { showThreatActionDialog = false },
                    confirmButton = {
                        Button(
                            onClick = {
                                showThreatActionDialog = false
                                activeBlockedUrlWarning = manualUrlText
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = neonRed)
                        ) {
                            Text("حظر الرابط فوراً 🛡️", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { expandMoreActions = !expandMoreActions }) {
                            Text("مزيد من الإجراءات ⚙️", color = neonCyan, fontWeight = FontWeight.Bold)
                        }
                    },
                    icon = { Icon(Icons.Default.Warning, contentDescription = "Security Intrusion", tint = neonRed, modifier = Modifier.size(48.dp)) },
                    title = { Text("خطر! تم اكتشاف رابط ضار!", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp, textAlign = TextAlign.Center) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                text = "الهدف: $manualUrlText\nالمحرك رصد محاولة استهداف من فئة: ${activeThreatResult?.threatCategory}\nالتأثير المحتمل: سرقة جلسات الدخول وحقن ثغرات متصفح الأندرويد.",
                                color = Color.LightGray,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Right
                            )

                            if (expandMoreActions) {
                                Divider(color = glassBorder)
                                Text("خيارات الدفاع الحيوية والمصادقة:", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                
                                Button(
                                    onClick = {
                                        showThreatActionDialog = false
                                        activeSandboxUrl = manualUrlText
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = neonCyan.copy(alpha = 0.2f)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("عزل الرابط في بيئة الـ Sandbox 🌐", color = neonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        showThreatActionDialog = false
                                        try {
                                            val systemWifiIntent = Intent(Settings.ACTION_WIFI_SETTINGS)
                                            context.startActivity(systemWifiIntent)
                                            Toast.makeText(context, "يرجى تعطيل شبكة الواي فاي أو البيانات الخلوية يدوياً لقطع الهجوم", Toast.LENGTH_LONG).show()
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "فشل تشغيل إعدادات الاتصال بالجهاز", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = neonRed.copy(alpha = 0.15f)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("قطع الاتصال الفوري بالإنترنت ⚠️", color = neonRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        showThreatActionDialog = false
                                        onToggleVpnRequested(true)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = neonGreen.copy(alpha = 0.15f)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("تفعيل نفق VPN الصامت لحجب الـ DNS 🔐", color = neonGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    },
                    containerColor = Color(0xFF140D10),
                    modifier = Modifier.border(1.dp, neonRed.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                )
            }

            // Beautiful full-page threat blocker warning overlay (Simulated link dropping/Local block state)
            activeBlockedUrlWarning?.let { url ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(cyberDarkBg.copy(alpha = 0.98f))
                        .clickable(enabled = false) {},
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp)
                            .background(Color(0xFF13080B), RoundedCornerShape(24.dp))
                            .border(2.dp, neonRed, RoundedCornerShape(24.dp))
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Blocked ALERT", tint = neonRed, modifier = Modifier.size(64.dp))
                        Text(
                            text = "تم حظر هذا الرابط لحمايتك بواسطة الدرع الدفاعي 🛡️",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = neonRed,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "تم رصد نشاط مريب وغير مصرح به على الرابط المستهدف:\n$url\n\nبناءً على سياسات الحماية الذاتية لواجهة حمّو الإلكتروني الدفاعية، تم إسقاط الاتصال وعزل البرمجيات الضارة لمنع سرقة صورك أو ملفاتك المخزنة.",
                            fontSize = 12.sp,
                            color = Color.LightGray,
                            lineHeight = 18.sp,
                            textAlign = TextAlign.Center
                        )
                        Button(
                            onClick = { activeBlockedUrlWarning = null },
                            colors = ButtonDefaults.buttonColors(containerColor = neonRed),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Text("العودة إلى اللوحة الآمنة", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Secure Air-Gapped Sandbox WebView container overlay
            activeSandboxUrl?.let { sandboxUrl ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(cyberDarkBg)
                        .padding(12.dp)
                        .clickable(enabled = false) {},
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Title bar with alert neon
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF1E0C0F), RoundedCornerShape(12.dp))
                                .border(1.dp, neonRed.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("🌐 متصفح العزل الإلكتروني لدرع حمّو (Sandbox)", color = neonRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("الهدف المعزول: $sandboxUrl", color = Color.LightGray, fontSize = 10.sp, maxLines = 1)
                                Text("أنماط الحماية: منع JavaScript | إيقاف Cookies | عزل شبكة الجلسة", color = Color.Gray, fontSize = 9.sp)
                            }
                            IconButton(onClick = { activeSandboxUrl = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Close Sandbox", tint = neonRed)
                            }
                        }

                        // Web view frame with JavaScript completely disabled for sandboxing
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .background(Color.White, RoundedCornerShape(16.dp))
                                .border(2.dp, neonRed, RoundedCornerShape(16.dp))
                                .clip(RoundedCornerShape(16.dp))
                        ) {
                            AndroidView(
                                factory = { ctx ->
                                    WebView(ctx).apply {
                                        webViewClient = WebViewClient()
                                        settings.apply {
                                            javaScriptEnabled = false // CRITICAL SECURITY REQUIREMENT
                                            allowFileAccess = false
                                            allowContentAccess = false
                                            setGeolocationEnabled(false)
                                            databaseEnabled = false
                                            domStorageEnabled = false
                                        }
                                        loadUrl(sandboxUrl)
                                    }
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Button(
                            onClick = { activeSandboxUrl = null },
                            colors = ButtonDefaults.buttonColors(containerColor = neonRed),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Text("خروج وإنهاء تذكرة العزل الآمنة 🔒", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SecurityAttestationWarningScreen(
    isEmulator: Boolean,
    isRooted: Boolean,
    onCloseApp: () -> Unit,
    onBypassDev: () -> Unit
) {
    val neonRed = Color(0xFFFE2C55)
    val neonGreen = Color(0xFF00FF41)
    val cyberDarkBg = Color(0xFF07090E)
    val glassCardBg = Color(0xFF111622)
    val glassBorder = Color(0xFF1E293B)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(cyberDarkBg)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(glassCardBg, RoundedCornerShape(24.dp))
                .border(1.dp, neonRed.copy(alpha = 0.6f), RoundedCornerShape(24.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Threat Detected",
                tint = neonRed,
                modifier = Modifier.size(72.dp)
            )

            Text(
                text = "تحذير: تم كشف بيئة تشغيل غير آمنة!",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = neonRed,
                textAlign = TextAlign.Center
            )

            Text(
                text = "بناءً على بروتوكولات حماية الهندسة العكسية لمنع تفكيك كود تطبيق درع حمّو الصامت (Anti-Debugging & Reverse Engineering Protection)، يرجى تجنب تشغيل التطبيق في البيئات الافتراضية أو الأجهزة التي تملك صلاحيات جذرية معدلة.",
                fontSize = 12.sp,
                color = Color.LightGray,
                lineHeight = 18.sp,
                textAlign = TextAlign.Center
            )

            // Diagnostic card list
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(cyberDarkBg, RoundedCornerShape(12.dp))
                    .border(1.dp, glassBorder, RoundedCornerShape(12.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("تقرير السلامة الهيكلية للجهاز:", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                
                AttestationRow(label = "أنماط محاكاة افتراضية نشطة", isDetected = isEmulator)
                AttestationRow(label = "صلاحيات الوصول للجذر (Rooting)", isDetected = isRooted)
                AttestationRow(label = "أطر حقن Frida / Xposed", isDetected = false)
            }

            Button(
                onClick = onCloseApp,
                colors = ButtonDefaults.buttonColors(containerColor = neonRed),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text("إغلاق التطبيق فوراً", color = Color.White, fontWeight = FontWeight.Bold)
            }

            TextButton(onClick = onBypassDev) {
                Text("استمرار في بيئة محاكاة التطوير (Sandbox Bypass) 🛠️", color = neonGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AttestationRow(label: String, isDetected: Boolean) {
    val neonRed = Color(0xFFFE2C55)
    val neonGreen = Color(0xFF00FF41)
    
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.LightGray, fontSize = 12.sp)
        Text(
            text = if (isDetected) "مكتشف (RISK)" else "آمن (SAFE)",
            color = if (isDetected) neonRed else neonGreen,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}
