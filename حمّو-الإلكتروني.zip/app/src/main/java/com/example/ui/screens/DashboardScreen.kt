package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainActivity
import com.example.data.ThreatLog

@Composable
fun DashboardScreenContent(
    context: Context,
    isVpnActive: Boolean,
    blockedUrlsCount: Int,
    safetyScore: Int,
    logs: List<ThreatLog>,
    onToggleVpnRequested: (Boolean) -> Unit,
    onClearLogsClicked: () -> Unit
) {
    val neonGreen = Color(0xFF00FF41)
    val neonRed = Color(0xFFFE2C55)
    val neonCyan = Color(0xFF00E5FF)
    val glassCardBg = Color(0xFF0F1524)
    val glassBorder = Color(0xFF1E293B)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Safe dial indicator
        Box(
            modifier = Modifier
                .size(160.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.4f))
                .border(2.dp, neonGreen.copy(alpha = 0.25f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$safetyScore%",
                    fontSize = 42.sp,
                    fontWeight = FontWeight.Black,
                    color = if (safetyScore > 75) neonGreen else if (safetyScore > 45) neonCyan else neonRed
                )
                Text("مستوى سلامة الاتصالات", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
            }
        }

        // VPN dynamic switch card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, if (isVpnActive) neonGreen.copy(alpha = 0.3f) else glassBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(if (isVpnActive) neonGreen.copy(alpha = 0.1f) else Color.Gray.copy(alpha = 0.1f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "VPN Shield Status",
                        tint = if (isVpnActive) neonGreen else Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isVpnActive) "الدرع الصامت نشط" else "الدرع الصامت غير مفعل",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                    Text(
                        text = if (isVpnActive) "حمّو الإلكتروني يحميك ويعزل الروابط الضارة بالخلفية" else "موافق دائم مطلوبة - اضغط للتفعيل والحماية",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
                Switch(
                    checked = isVpnActive,
                    onCheckedChange = { active ->
                        onToggleVpnRequested(active)
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = neonGreen,
                        checkedTrackColor = neonGreen.copy(alpha = 0.3f)
                    )
                )
            }
        }

        // Community support card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, neonCyan.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                .clickable {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@hamoelectronic"))
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(context, "فشل فتح الرابط الخارجي لقناة المجتمع", Toast.LENGTH_SHORT).show()
                    }
                },
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1322))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(neonCyan.copy(alpha = 0.1f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "انضم لمجتمعنا",
                        tint = neonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "انضم لمجتمع حمّو الإلكتروني 🚀",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                    Text(
                        text = "لتبقى على اطلاع بأحدث الثغرات وكيفية هندستها والحماية منها، انضم لقناتنا الرسمية الآن.",
                        fontSize = 11.sp,
                        color = Color.LightGray,
                        lineHeight = 15.sp
                    )
                }
                Icon(Icons.Default.PlayArrow, contentDescription = "اذهب", tint = neonCyan)
            }
        }

        // Statistics Panel
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = glassCardBg),
                border = BorderStroke(1.dp, glassBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("محاولات الفحص", fontSize = 11.sp, color = Color.Gray)
                    Text("${logs.size}", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = glassCardBg),
                border = BorderStroke(1.dp, glassBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("حجوبات الـ DNS", fontSize = 11.sp, color = Color.Gray)
                    Text("$blockedUrlsCount", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = neonRed)
                }
            }
        }

        // Threat Logs Header block
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("سجلات التهديدات وفحص الخلفية الحية", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
            if (logs.isNotEmpty()) {
                IconButton(onClick = onClearLogsClicked) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "مسح سجل الفحص", tint = neonRed)
                }
            }
        }

        if (logs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "جهازك آمن جداً! لم يتم الكشف عن روابط ضارة حتى الآن في الدرع الصامت.",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            logs.reversed().forEach { log ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = glassCardBg),
                    border = BorderStroke(1.dp, glassBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = log.threatCategory,
                                color = if (log.riskType == "SAFE") neonGreen else neonRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "درجة السلامة: ${log.securityScore}/4",
                                color = Color.Gray,
                                fontSize = 10.sp
                            )
                        }
                        Text(
                            text = log.url,
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                        Text(
                            text = log.analysisLog,
                            color = Color.Gray,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }
    }
}
