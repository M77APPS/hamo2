package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainActivity
import com.example.data.VaultItem

@Composable
fun VaultScreenContent(
    context: Context,
    vaultItems: List<VaultItem>,
    isBiometricLockEnabled: Boolean,
    totpCode: String,
    totpProgress: Float,
    totpSecondsLeft: Int,
    onToggleBiometricLock: (Boolean) -> Unit,
    onSaveSecretClicked: (title: String, rawContent: String, pin: String) -> Unit,
    onDecryptRequested: (VaultItem, pin: String, onSuccess: (String) -> Unit) -> Unit,
    onDeleteSecretClicked: (VaultItem) -> Unit
) {
    val neonGreen = Color(0xFF00FF41)
    val neonRed = Color(0xFFFE2C55)
    val neonCyan = Color(0xFF00E5FF)
    val glassCardBg = Color(0xFF0F1524)
    val glassBorder = Color(0xFF1E293B)

    var secretTitle by remember { mutableStateOf("") }
    var secretContent by remember { mutableStateOf("") }
    var secretPin by remember { mutableStateOf("") }

    var decryptingItem by remember { mutableStateOf<VaultItem?>(null) }
    var inputDecryptPin by remember { mutableStateOf("") }
    var revealedContentDialogText by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Biometric sync switch card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F131E)),
            border = BorderStroke(1.dp, glassBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("ربط القفل الحيوي بمخزن Android Keystore 🧬", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("حماية الخزنة السيبرانية والتحويلات الخارجية ببصمة الهاتف", color = Color.Gray, fontSize = 11.sp)
                }
                Switch(
                    checked = isBiometricLockEnabled,
                    onCheckedChange = { onToggleBiometricLock(it) },
                    colors = SwitchDefaults.colors(checkedThumbColor = neonGreen, checkedTrackColor = neonGreen.copy(alpha = 0.3f))
                )
            }
        }

        // TOTP Generator Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F131E)),
            border = BorderStroke(1.dp, glassBorder)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(10.dp).background(neonCyan, CircleShape))
                        Text("مُولد الرموز ثنائية الأمان (TOTP) ⏳", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Text("مؤقت: ${totpSecondsLeft}s", color = neonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                LinearProgressIndicator(
                    progress = totpProgress,
                    color = neonCyan,
                    trackColor = Color.DarkGray,
                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp))
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = totpCode,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    color = neonGreen,
                    textAlign = TextAlign.Center,
                    letterSpacing = 2.sp
                )
                Text("رمز الأمان المؤقت للمصادقة الدفاعية والتأكيد التلقائي", color = Color.Gray, fontSize = 10.sp)
            }
        }

        // Vault item insert fields
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("حفظ وتشفير محتوى جديد بالخزنة", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)

                OutlinedTextField(
                    value = secretTitle,
                    onValueChange = { secretTitle = it },
                    label = { Text("عنوان المحتوى (مثال: حساب المحفظة البنكية)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = neonGreen, unfocusedBorderColor = glassBorder)
                )

                OutlinedTextField(
                    value = secretContent,
                    onValueChange = { secretContent = it },
                    label = { Text("المحتوى السري لعزله وتشفيره") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = neonGreen, unfocusedBorderColor = glassBorder)
                )

                OutlinedTextField(
                    value = secretPin,
                    onValueChange = { secretPin = it },
                    label = { Text("رمز حماية التشفير (رقم سري PIN)") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = neonGreen, unfocusedBorderColor = glassBorder)
                )

                Button(
                    onClick = {
                        if (secretTitle.isBlank() || secretContent.isBlank() || secretPin.isBlank()) {
                            Toast.makeText(context, "الرجاء كشط وإدخال كل الملفات والبيانات والرمز!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        onSaveSecretClicked(secretTitle, secretContent, secretPin)
                        secretTitle = ""
                        secretContent = ""
                        secretPin = ""
                        Toast.makeText(context, "تم التشفير والتخزين بالخزنة الحديدية بنجاح 🛡️", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = neonGreen),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("🛡️ تشفير وحفظ مشفر بـ AES-256", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Render vault items lists
        Text(
            text = "محتويات الخزنة المشفرة عسكرياً (${vaultItems.size})",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            modifier = Modifier.fillMaxWidth()
        )

        if (vaultItems.isEmpty()) {
            Text(
                text = "الخزنة فارغة حالياً. لا يوجد بيانات مهددة أو مشفرة معزولة.",
                color = Color.Gray,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(16.dp)
            )
        } else {
            vaultItems.forEach { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = glassCardBg),
                    border = BorderStroke(1.dp, glassBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier.weight(1f).clickable {
                                decryptingItem = item
                            }
                        ) {
                            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                            val dateStr = try { sdf.format(java.util.Date(item.timestamp)) } catch (e: Exception) { item.timestamp.toString() }
                            Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("تاريخ الحفظ: $dateStr", color = Color.Gray, fontSize = 10.sp)
                            Text("البيانات المشفرة: ${item.encryptedContent.take(20)}...", color = neonCyan, fontSize = 10.sp)
                        }
                        IconButton(onClick = { onDeleteSecretClicked(item) }) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "مسح السر", tint = neonRed)
                        }
                    }
                }
            }
        }
    }

    // Decryption PIN Dialog Prompt
    if (decryptingItem != null) {
        AlertDialog(
            onDismissRequest = {
                decryptingItem = null
                inputDecryptPin = ""
            },
            title = { Text("حماية الخزنة العسكرية 🛡️", color = neonGreen) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("الرجاء إدخال رمز الـ PIN المخصص لفك تشفير المحتوى السري:", color = Color.White, fontSize = 13.sp)
                    OutlinedTextField(
                        value = inputDecryptPin,
                        onValueChange = { inputDecryptPin = it },
                        label = { Text("رمز حماية الـ PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = neonGreen)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val item = decryptingItem ?: return@Button
                        onDecryptRequested(item, inputDecryptPin) { content ->
                            revealedContentDialogText = content
                            decryptingItem = null
                            inputDecryptPin = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = neonGreen)
                ) {
                    Text("فك التشفير", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    decryptingItem = null
                    inputDecryptPin = ""
                }) {
                    Text("إلغاء", color = Color.Gray)
                }
            },
            containerColor = glassCardBg
        )
    }

    // Revealed Decrypted Content Dialog
    if (revealedContentDialogText != null) {
        AlertDialog(
            onDismissRequest = { revealedContentDialogText = null },
            title = { Text("المحتوى السري المفكوك تشفيره 🔑", color = neonGreen) },
            text = {
                val text = revealedContentDialogText ?: ""
                Text(
                    text = text,
                    color = if (text.startsWith("رمز الحماية") || text.startsWith("خطأ")) neonRed else Color.White,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { revealedContentDialogText = null },
                    colors = ButtonDefaults.buttonColors(containerColor = neonGreen)
                ) {
                    Text("حسناً يا بطل", color = Color.Black)
                }
            },
            containerColor = glassCardBg
        )
    }
}
