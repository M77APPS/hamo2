package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AboutScreenContent(context: Context) {
    val neonGreen = Color(0xFF00FF41)
    val neonRed = Color(0xFFFE2C55)
    val neonCyan = Color(0xFF00E5FF)
    val glassCardBg = Color(0xFF0F1524)
    val glassBorder = Color(0xFF1E293B)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Avatar Panel
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, neonGreen.copy(alpha = 0.3f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .background(neonGreen.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                        .border(1.dp, neonGreen, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Hemo Electronic Signature",
                        tint = neonGreen,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Text(
                    text = "محمد حسام (حمّو الإلكتروني) 👨‍💻",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )

                Text(
                    text = "\"المحترفون يبنون أدواتهم، والهواة يستخدمون أدوات الآخرين.\"",
                    fontSize = 12.sp,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                    color = neonCyan,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    lineHeight = 16.sp
                )
            }
        }

        // Project introduction card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "مفهوم مشروع \"الدرع الصامت\":",
                    color = neonGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "تطبيق أمان وهندسة عكسية دفاعية متقدم، صممه حمّو الإلكتروني لتقديم درع حماية متكامل مخصص لأجهزة أندرويد لحجب هجمات وتصيدات الروابط الضارة (Phishing) والبرمجيات الخبيثة قبل فتحها بالمتصفح، وتشفير الأسرار وحفظ الرموز الثنائية.",
                    color = Color.White,
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                    textAlign = TextAlign.Justify
                )
            }
        }

        // Compliance details
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "موافقة المستخدم وسياسة جوجل بلاي الرسمية: 🛡️",
                    color = neonCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "يتوافق هذا التطبيق تماماً مع متطلبات متجر Google Play. كافة علميات حظر وفلترة الروابط تتم محلياً 100% داخل جهازك عن طريق استخدام بروتوكول VpnService لغايات تصفية الـ DNS دون خوادم تمثيلية خارجية ودون إعلانات. التطبيق يطلب موافقة صريحة للمبادئ الأساسية قبل تمكين الحماية ولا يقوم بجمع أي معلومات شخصية أو الاتصالات المشفرة لمستخدمي التطبيق.",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    textAlign = TextAlign.Justify
                )
            }
        }

        // Contact link button
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, glassBorder, RoundedCornerShape(12.dp))
                .clickable {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@hamoelectronic"))
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(context, "لا يمكن تشغيل المتصفح الخارجي", Toast.LENGTH_SHORT).show()
                    }
                },
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1322))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("تواصل مع المطور حمّو الإلكتروني على يوتيوب", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Icon(Icons.Default.PlayArrow, contentDescription = "قناة يوتيوب", tint = neonGreen)
            }
        }

        // Disclaimer statement card
        Text(
            text = "إشلاء مسؤولية أمني: تم تصميم كافة الأدوات الحية الحيوية لأغراض التدريب والتوعية الأمنية وحماية الهواتف الشخصية. المطور غير مسؤول عن أي استخدام يخالف سياسات الأمان أو القوانين العامة المنظمة للمعلومات الرقمية المحلية.",
            color = Color.Gray,
            fontSize = 9.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(10.dp)
        )
    }
}
