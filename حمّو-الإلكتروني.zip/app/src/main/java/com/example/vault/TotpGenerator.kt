package com.example.vault

import java.nio.ByteBuffer
import java.security.InvalidKeyException
import java.security.NoSuchAlgorithmException
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.experimental.and

object TotpGenerator {

    private const val TOTP_PERIOD_SEC = 30
    private const val CODE_DIGITS = 6

    /**
     * Generates a 6-digit standard TOTP code for a given secret base string and timestamp.
     */
    fun generateTotp(secret: String, timeMs: Long = System.currentTimeMillis()): String {
        try {
            // Convert secret string into raw bytes
            val keyBytes = secret.toByteArray(Charsets.UTF_8)
            val timeIndex = timeMs / 1000 / TOTP_PERIOD_SEC

            val data = ByteBuffer.allocate(8).putLong(timeIndex).array()
            val signKey = SecretKeySpec(keyBytes, "HmacSHA1")
            
            val mac = Mac.getInstance("HmacSHA1")
            mac.init(signKey)
            val hash = mac.doFinal(data)

            // Dynamic Truncation
            val offset = (hash[hash.size - 1] and 0xf).toInt()
            val binary = (
                ((hash[offset].toInt() and 0x7f) shl 24) or
                ((hash[offset + 1].toInt() and 0xff) shl 16) or
                ((hash[offset + 2].toInt() and 0xff) shl 8) or
                (hash[offset + 3].toInt() and 0xff)
            )

            val otp = binary % 1000000
            var otpStr = otp.toString()
            while (otpStr.length < CODE_DIGITS) {
                otpStr = "0$otpStr"
            }
            return otpStr
        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
        } catch (e: InvalidKeyException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return "000000"
    }

    /**
     * Calculates the remaining seconds left in the current 30-second cycle.
     */
    fun getSecondsRemainingInCycle(timeMs: Long = System.currentTimeMillis()): Int {
        val secondsSinceEpoch = timeMs / 1000
        return (TOTP_PERIOD_SEC - (secondsSinceEpoch % TOTP_PERIOD_SEC)).toInt()
    }
}
