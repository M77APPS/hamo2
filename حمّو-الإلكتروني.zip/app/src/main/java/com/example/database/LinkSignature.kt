package com.example.database

import androidx.room.*

@Entity(tableName = "LinkSignature")
data class LinkSignature(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    @ColumnInfo(name = "pattern") val pattern: String,
    @ColumnInfo(name = "riskSeverity") val riskSeverity: String, // e.g. MALICIOUS, PHISHING, UNKNOWN
    @ColumnInfo(name = "description") val description: String
)
