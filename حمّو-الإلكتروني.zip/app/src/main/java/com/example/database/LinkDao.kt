package com.example.database

import androidx.room.*

@Dao
interface LinkDao {

    @Query("SELECT * FROM LinkSignature WHERE :url LIKE '%' || pattern || '%' LIMIT 1")
    suspend fun findMatchingSignature(url: String): LinkSignature?

    @Query("SELECT COUNT(*) FROM LinkSignature")
    suspend fun getSignaturesCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSignature(sig: LinkSignature)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSignatures(list: List<LinkSignature>)

    @Delete
    suspend fun deleteSignature(sig: LinkSignature)

    @Query("DELETE FROM LinkSignature")
    suspend fun clearSignatures()
}
