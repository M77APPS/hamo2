package com.example.service

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.ListenableWorker.Result
import com.example.data.AppDatabase
import com.example.data.SecurityRepository
import com.example.data.ThreatLog

class SyncWorker(appContext: Context, workerParams: WorkerParameters) : CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): Result {
        return try {
            val database = androidx.room.Room.databaseBuilder(
                applicationContext,
                AppDatabase::class.java, "hemo_shield_db"
            ).build()
            
            val threatLogDao = database.threatLogDao()
            val vaultItemDao = database.vaultItemDao()
            val securityRepository = SecurityRepository(applicationContext, threatLogDao, vaultItemDao)
            
            // Sync with remote APIs, fetch dangerous signatures (Mock update)
            val countBefore = threatLogDao.getLogsCount()
            
            // Ensure db contains template records
            if (countBefore == 0) {
                threatLogDao.insertLog(
                    ThreatLog(
                        url = "http://evil-example-phishing-scam.ru/login",
                        securityScore = 4,
                        riskType = "MALICIOUS",
                        threatCategory = "التصيد الاحتيالي (Phishing)",
                        analysisLog = "تم تحديث هجمات التصيد الاحتيالي بنجاح في قاعدة البيانات المحلية."
                    )
                )
                threatLogDao.insertLog(
                    ThreatLog(
                        url = "http://zeroclick-payload-injection.io/payload.sh",
                        securityScore = 0,
                        riskType = "ZERO_DAY",
                        threatCategory = "استغلال ثغرة نظام تلقائية (Zero-Day Exploit)",
                        analysisLog = "تم دمج ملفات الحماية التلقائية للشبكات الصامتة."
                    )
                )
            }
            database.close()
            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.retry()
        }
    }
}
