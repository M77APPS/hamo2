package com.example.utils

import android.content.Context
import android.os.Build
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.Socket

object EnvironmentChecker {

    /**
     * Verifies if the device is running inside an emulator.
     */
    fun isEmulator(): Boolean {
        return (Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.startsWith("unknown")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MANUFACTURER.contains("Genymotion")
                || Build.HARDWARE.contains("goldfish")
                || Build.HARDWARE.contains("ranchu")
                || Build.PRODUCT.contains("sdk_gphone")
                || Build.PRODUCT.contains("google_sdk")
                || Build.PRODUCT.contains("sdk")
                || Build.PRODUCT.contains("sdk_x86")
                || Build.PRODUCT.contains("vbox86p")
                || Build.BOARD.lowercase().contains("nox")
                || Build.BOOTLOADER.lowercase().contains("nox")
                || Build.HARDWARE.lowercase().contains("nox")
                || Build.PRODUCT.lowercase().contains("nox"))
    }

    /**
     * Scans for elevated root binary permissions.
     */
    fun isRooted(): Boolean {
        // 1. Check Build Tags for test-keys (indicative of custom root ROMs)
        val buildTags = Build.TAGS
        if (buildTags != null && buildTags.contains("test-keys")) {
            return true
        }

        // 2. Scan standard folders for common root management application packages or binaries
        val paths = arrayOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/usr/we-need-su/su",
            "/su/bin/su"
        )
        for (path in paths) {
            if (File(path).exists()) {
                return true
            }
        }

        // 3. Execute 'which su' via background runtime commands safely
        var process: Process? = null
        try {
            process = Runtime.getRuntime().exec(arrayOf("/system/xbin/which", "su"))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            if (reader.readLine() != null) {
                return true
            }
        } catch (e: Exception) {
            // Safe ignore
        } finally {
            process?.destroy()
        }

        return false
    }

    /**
     * Checks if Frida dynamic instrumentation or Xposed Framework hooks are loaded.
     */
    fun isFridaOrXposedDetected(context: Context): Boolean {
        // 1. Detect Xposed via reflection
        try {
            Class.forName("de.robv.android.xposed.XposedBridge")
            return true // Xposed hook is active
        } catch (e: ClassNotFoundException) {
            // Safe
        }

        // 2. Check for Xposed active exception stack trace footprint
        try {
            throw Exception("Xposed检测异常")
        } catch (e: Exception) {
            for (element in e.stackTrace) {
                if (element.className.contains("de.robv.android.xposed")) {
                    return true
                }
            }
        }

        // 3. Simulated/basic port scanners check for default Frida server listening on 27042
        // Run in thread or safe execution since socket block must not crash UI thread directly
        var fridaPortFound = false
        val checkThread = Thread {
            try {
                val socket = Socket("127.0.0.1", 27042)
                socket.close()
                fridaPortFound = true
            } catch (e: Exception) {
                // Not found, expected
            }
        }
        try {
            checkThread.start()
            checkThread.join(300) // Restricted 300ms connection timeout to prevent hanging UI thread
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return fridaPortFound
    }
}
