package com.example

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.data.SecurityRepository
import com.example.service.HemoVpnService
import com.example.ui.SecurityDashboardScreen
import com.example.ui.SecurityAttestationWarningScreen
import com.example.ui.SecurityViewModel
import com.example.ui.SecurityViewModelFactory
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val TAG = "MainActivity"
    private val REQUEST_VPN = 1002
    private var interceptedUrlState = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize local SQLite Room database with migrations enabled
        val database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "hemo_shield_db"
        ).fallbackToDestructiveMigration()
         .build()

        val threatLogDao = database.threatLogDao()
        val vaultItemDao = database.vaultItemDao()
        val securityRepository = SecurityRepository(applicationContext, threatLogDao, vaultItemDao)

        // 2. Instantiate state ViewModel
        val viewModel: SecurityViewModel by viewModels {
            SecurityViewModelFactory(securityRepository)
        }

        // Try launching the permanent background monitoring service
        try {
            val fgsIntent = Intent(this, com.example.service.HemoForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(fgsIntent)
            } else {
                startService(fgsIntent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed launching HemoForegroundService", e)
        }

        // 3. Handle incoming URL view intent interceptions if opening links externally
        handleIncomingIntent(intent)

        // 4. Run reverse engineering & emulator risk scans using centralized EnvironmentChecker
        val isEmulator = com.example.utils.EnvironmentChecker.isEmulator()
        val isRooted = com.example.utils.EnvironmentChecker.isRooted()
        val hasRiskEnvironment = isEmulator || isRooted

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val interceptedUrl by interceptedUrlState
                    var isBypassedForDev by remember { mutableStateOf(!hasRiskEnvironment) }

                    if (!isBypassedForDev) {
                        // High-tech Cyber Attestation center warning
                        SecurityAttestationWarningScreen(
                            isEmulator = isEmulator,
                            isRooted = isRooted,
                            onCloseApp = { finishAffinity() },
                            onBypassDev = { isBypassedForDev = true }
                        )
                    } else {
                        // Fully unlocked dashboard displaying community support organically
                        SecurityDashboardScreen(
                            viewModel = viewModel,
                            interceptedUrl = interceptedUrl,
                            onClearInterceptedUrl = { interceptedUrlState.value = null },
                            onToggleVpnRequested = { enable ->
                                if (enable) {
                                    requestVpnConsent()
                                } else {
                                    stopVpnService()
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    private fun checkIsEmulator(): Boolean {
        return (Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.startsWith("unknown")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MANUFACTURER.contains("Genymotion")
                || (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic"))
                || "google_sdk" == Build.PRODUCT)
    }

    private fun checkIsRooted(): Boolean {
        val paths = arrayOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su"
        )
        for (path in paths) {
            if (java.io.File(path).exists()) return true
        }
        return false
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        intent?.let {
            if (it.hasExtra("INTERCEPTED_URL_KEY")) {
                val urlString = it.getStringExtra("INTERCEPTED_URL_KEY")
                if (!urlString.isNullOrBlank()) {
                    interceptedUrlState.value = urlString
                }
            } else if (Intent.ACTION_VIEW == it.action) {
                val data = it.data
                if (data != null) {
                    interceptedUrlState.value = data.toString()
                }
            }
        }
    }

    /**
     * Google Play Compliant VpnService consent request
     */
    private fun requestVpnConsent() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            // User consent dialog required by OS
            startActivityForResult(intent, REQUEST_VPN)
        } else {
            // Consent already given previously, start VPN directly
            onActivityResult(REQUEST_VPN, RESULT_OK, null)
        }
    }

    private fun stopVpnService() {
        val serviceIntent = Intent(this, HemoVpnService::class.java)
        stopService(serviceIntent)
        Toast.makeText(this, "تم إيقاف تفعيل الدرع الصامت VPN بنجاح", Toast.LENGTH_SHORT).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VPN) {
            if (resultCode == RESULT_OK) {
                val serviceIntent = Intent(this, HemoVpnService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent)
                } else {
                    startService(serviceIntent)
                }
                Toast.makeText(this, "الدرع الصامت نشط - حمّو الإلكتروني يحميك", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "تم رفض تفعيل الدرع VPN. حماية المتصفح معطلة.", Toast.LENGTH_LONG).show()
            }
        }
    }
}

